const http = require("http");
const fs = require("fs");
const path = require("path");

const host = process.env.HOST || "0.0.0.0";
const port = Number(process.env.PORT || 8080);
const root = path.resolve(__dirname, "public");
const contentTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp"
};

const server = http.createServer((request, response) => {
  const pathname = decodeURIComponent(new URL(request.url, "http://localhost").pathname);
  const relativePath = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const requestedFile = path.resolve(root, relativePath);

  if (!requestedFile.startsWith(root + path.sep) && requestedFile !== path.join(root, "index.html")) {
    response.writeHead(403, { "Content-Type": "text/plain; charset=utf-8" });
    response.end("Forbidden");
    return;
  }

  fs.readFile(requestedFile, (error, data) => {
    if (!error) {
      response.writeHead(200, {
        "Content-Type": contentTypes[path.extname(requestedFile).toLowerCase()] || "application/octet-stream",
        "X-Content-Type-Options": "nosniff",
        "Referrer-Policy": "strict-origin-when-cross-origin"
      });
      response.end(data);
      return;
    }

    fs.readFile(path.join(root, "index.html"), (fallbackError, fallback) => {
      if (fallbackError) {
        response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
        response.end("Not found");
        return;
      }
      response.writeHead(200, { "Content-Type": contentTypes[".html"] });
      response.end(fallback);
    });
  });
});

server.listen(port, host, () => {
  console.log(`SoftwareOne prototype running on http://${host}:${port}`);
});

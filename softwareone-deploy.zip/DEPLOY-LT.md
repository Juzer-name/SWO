# SoftwareOne SMB prototipo diegimas

Tai statinė demonstracinė svetainė. Ji neturi duomenų bazės, autentifikacijos ar tikro formų ir parašų saugojimo. Įvesti duomenys niekur nesiunčiami.

## Variantas A — esamas web serveris

Jeigu serveryje jau turite IIS, Nginx, Apache, Caddy ar kitą web serverį, nukopijuokite visą `public` katalogo turinį į svetainės dokumentų katalogą:

- `index.html`
- `styles.css`
- `app.js`

Svetainės pradinis dokumentas turi būti `index.html`. Papildomo build proceso ar paketų diegimo nereikia.

## Variantas B — Node.js

Reikalingas tik jau įdiegtas Node.js. Jokių `npm install` komandų vykdyti nereikia.

Windows serveryje paleiskite `START-WINDOWS.bat` arba terminale:

```powershell
npm start
```

Linux serveryje:

```bash
npm start
```

Pagal nutylėjimą svetainė klausosi visų tinklo sąsajų per `8080` prievadą:

```text
http://SERVERIO-IP:8080
```

Kitą prievadą galima nurodyti aplinkos kintamuoju `PORT`, pavyzdžiui `PORT=3000`.

## Viešas arba įmonės tinklo adresas

Kad svetainę pasiektų kiti žmonės:

1. Ugniasienėje leiskite pasirinktą TCP prievadą.
2. Jeigu naudojamas domenas, nukreipkite DNS į serverį.
3. Viešai svetainei naudokite HTTPS per IIS, Nginx, Caddy arba kitą reverse proxy.
4. Node serverį ilgalaikiam naudojimui paleiskite kaip sistemos servisą, o ne atidarytame terminalo lange.

## Svarbu prieš naudojant tikrus duomenis

Šis paketas skirtas tik demonstracijai. Prieš renkant realius klientų kontaktus, IT aplinkos informaciją ar parašus reikės serverinės dalies, autentifikacijos, duomenų bazės, prieigos kontrolės, audito istorijos, privatumo dokumentų ir tinkamo elektroninio pasirašymo sprendimo.
